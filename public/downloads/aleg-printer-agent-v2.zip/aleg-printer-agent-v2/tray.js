/**
 * TRAY CONTROLLER
 *
 * Sistem tray icon + sağ tık menü.
 * node-systray-v2 paketini kullanır (cross-platform Go binary, Node'dan IPC).
 *
 * Status:
 *   - 'connecting' / 'connected' / 'disconnected' / 'error' / 'paused'
 *
 * Eventlar:
 *   - 'open-dashboard' → ana script dashboard'u açar
 *   - 'pause' / 'resume'
 *   - 'open-log'
 *   - 'restart'
 *   - 'quit'
 */

const path = require('path');
const fs = require('fs');
const { spawn } = require('child_process');
const { EventEmitter } = require('events');

let SysTray;
try {
  SysTray = require('systray2').default;
} catch (e) {
  SysTray = null;
}

class TrayController extends EventEmitter {
  constructor(opts = {}) {
    super();
    this.agentName = opts.agentName || 'Aleg Agent';
    this.dashboardUrl = opts.dashboardUrl || 'http://127.0.0.1:38274';
    this.tray = null;
    this.status = 'connecting';
    this.jobsToday = 0;
    this.lastJobAt = null;
    this.paused = false;
    this.errorMsg = null;
  }

  _iconPath(name) {
    const p = path.join(__dirname, name);
    if (fs.existsSync(p)) return p;
    return path.join(__dirname, 'icon.ico');
  }

  _currentIcon() {
    if (this.status === 'error' || this.status === 'disconnected') {
      return this._iconPath('icon-error.ico');
    }
    if (this.status === 'connected') {
      return this._iconPath('icon-online.ico');
    }
    return this._iconPath('icon.ico');
  }

  _currentTooltip() {
    const lines = [`Aleg Printer Agent · ${this.agentName}`];
    if (this.paused) {
      lines.push('Durum: ⏸ Duraklatıldı');
    } else {
      switch (this.status) {
        case 'connected':
          lines.push('Durum: 🟢 Bağlı');
          break;
        case 'connecting':
          lines.push('Durum: ⏳ Bağlanıyor...');
          break;
        case 'disconnected':
          lines.push('Durum: 🔴 Bağlantı yok');
          break;
        case 'error':
          lines.push(`Durum: ⚠ Hata${this.errorMsg ? ': ' + this.errorMsg : ''}`);
          break;
      }
    }
    if (this.jobsToday > 0) {
      lines.push(`Bugün: ${this.jobsToday} fiş`);
    }
    return lines.join('\n');
  }

  start() {
    if (!SysTray) {
      console.error('[tray] systray2 paketi yüklü değil — tray olmadan devam ediliyor');
      return false;
    }

    try {
      const iconPath = this._currentIcon();
      const iconBuffer = fs.readFileSync(iconPath);

      this.tray = new SysTray({
        menu: {
          icon: iconBuffer.toString('base64'),
          isTemplateIcon: false,
          title: '',
          tooltip: this._currentTooltip(),
          items: this._buildMenu(),
        },
        debug: false,
        copyDir: false,
      });

      this.tray.onClick((action) => {
        const handlers = [
          'open-dashboard',  // 0
          null,               // 1: separator
          'toggle-pause',    // 2
          'open-log',        // 3
          'restart',         // 4
          null,               // 5: separator
          'about',           // 6
          'quit',            // 7
        ];
        const event = handlers[action.seq_id];
        if (event) {
          this.emit(event);
        }
      });

      this.tray.ready().then(() => {
        // Tray hazır
      }).catch((err) => {
        console.error('[tray] ready hatası:', err.message);
      });

      return true;
    } catch (err) {
      console.error('[tray] başlatma hatası:', err.message);
      return false;
    }
  }

  _buildMenu() {
    return [
      {
        title: '📊  Dashboard\'ı Aç',
        tooltip: 'Tarayıcıda dashboard\'u aç',
        checked: false,
        enabled: true,
      },
      { title: '__SEPARATOR__', enabled: false, checked: false },
      {
        title: this.paused ? '▶  Devam Et' : '⏸  Duraklat',
        tooltip: this.paused ? 'Yazdırmayı sürdür' : 'Yazdırmayı geçici durdur',
        checked: false,
        enabled: true,
      },
      {
        title: '📁  Log Dosyasını Aç',
        tooltip: 'agent.log dosyasını aç',
        checked: false,
        enabled: true,
      },
      {
        title: '🔄  Yeniden Başlat',
        tooltip: 'Agent\'ı yeniden başlat',
        checked: false,
        enabled: true,
      },
      { title: '__SEPARATOR__', enabled: false, checked: false },
      {
        title: 'Hakkında',
        tooltip: 'Aleg Printer Agent v2.0',
        checked: false,
        enabled: true,
      },
      {
        title: '🚪  Çıkış',
        tooltip: 'Agent\'ı tamamen kapat',
        checked: false,
        enabled: true,
      },
    ];
  }

  setStatus(status, errorMsg = null) {
    this.status = status;
    this.errorMsg = errorMsg;
    this._updateIconAndTooltip();
  }

  setJobsToday(count) {
    this.jobsToday = count;
    this._updateIconAndTooltip();
  }

  setPaused(paused) {
    this.paused = paused;
    this._updateIconAndTooltip();
    this._rebuildMenu();
  }

  _updateIconAndTooltip() {
    if (!this.tray) return;
    try {
      const iconPath = this._currentIcon();
      const iconBuffer = fs.readFileSync(iconPath);
      this.tray.sendAction({
        type: 'update-menu',
        menu: {
          icon: iconBuffer.toString('base64'),
          isTemplateIcon: false,
          title: '',
          tooltip: this._currentTooltip(),
          items: this._buildMenu(),
        },
      });
    } catch (err) {
      // Sessizce yut
    }
  }

  _rebuildMenu() {
    this._updateIconAndTooltip();
  }

  /** Tarayıcıda bir URL aç (cross-platform) */
  openUrl(url) {
    const platform = process.platform;
    let cmd, args;
    if (platform === 'win32') {
      cmd = 'cmd';
      args = ['/c', 'start', '""', url];
    } else if (platform === 'darwin') {
      cmd = 'open';
      args = [url];
    } else {
      cmd = 'xdg-open';
      args = [url];
    }
    try {
      spawn(cmd, args, { detached: true, stdio: 'ignore' }).unref();
    } catch (err) {
      console.error('[tray] URL açma hatası:', err.message);
    }
  }

  /** Dosya/klasör aç (cross-platform) */
  openPath(filePath) {
    const platform = process.platform;
    let cmd, args;
    if (platform === 'win32') {
      cmd = 'cmd';
      args = ['/c', 'start', '""', filePath];
    } else if (platform === 'darwin') {
      cmd = 'open';
      args = [filePath];
    } else {
      cmd = 'xdg-open';
      args = [filePath];
    }
    try {
      spawn(cmd, args, { detached: true, stdio: 'ignore' }).unref();
    } catch (err) {
      console.error('[tray] dosya açma hatası:', err.message);
    }
  }

  destroy() {
    if (this.tray) {
      try { this.tray.kill(false); } catch {}
      this.tray = null;
    }
  }
}

module.exports = { TrayController };
