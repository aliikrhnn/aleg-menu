' Aleg Printer Agent v2 - Gizli baslatici
' Konsol penceresi gosterilmez. Tray icon gorunur.
' Tray icon sag alt kosede!
Set WshShell = CreateObject("WScript.Shell")
WshShell.CurrentDirectory = CreateObject("Scripting.FileSystemObject").GetParentFolderName(WScript.ScriptFullName)
WshShell.Run "cmd /c node agent.js > agent.log 2>&1", 0, False
Set WshShell = Nothing
