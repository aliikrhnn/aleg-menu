/**
 * İlk kurulum wizard'ı (v1 ile aynı)
 */
const { createClient } = require('@supabase/supabase-js');
const fs = require('fs');
const path = require('path');
const readline = require('readline');
const crypto = require('crypto');

const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
function ask(q) { return new Promise((resolve) => rl.question(q, resolve)); }

async function main() {
  console.log('');
  console.log('╔════════════════════════════════════════╗');
  console.log('║   ALEG PRINTER AGENT v2 - KURULUM      ║');
  console.log('╚════════════════════════════════════════╝');
  console.log('');
  console.log('Bu script agent\'ı işletmenize bağlar.');
  console.log('Bilgileri Aleg panel yetkilisinden alın.');
  console.log('');

  const envPath = path.join(__dirname, '.env');
  if (fs.existsSync(envPath)) {
    const overwrite = await ask('⚠  .env dosyası var. Üzerine yazılsın mı? (e/h): ');
    if (overwrite.toLowerCase() !== 'e') {
      console.log('İptal edildi.');
      rl.close();
      return;
    }
  }

  const supabaseUrl = (await ask('Supabase URL: ')).trim();
  const supabaseKey = (await ask('Supabase Service Role Key: ')).trim();
  const businessId = (await ask('İşletme ID: ')).trim();
  const agentName = (await ask('Bu bilgisayarın adı (örn: "Kasa PC"): ')).trim() || 'Aleg Agent';
  const panelUrl = (await ask('Panel URL (boşsa https://alegstudio.com): ')).trim() || 'https://alegstudio.com';

  if (!supabaseUrl || !supabaseKey || !businessId) {
    console.log('\n⛔ Zorunlu alanlar boş.');
    rl.close();
    return;
  }

  console.log('\n🔌 Supabase bağlantısı test ediliyor...');
  const supabase = createClient(supabaseUrl, supabaseKey, { auth: { persistSession: false } });

  const { data: business, error: bizErr } = await supabase
    .from('businesses').select('id, name').eq('id', businessId).maybeSingle();

  if (bizErr || !business) {
    console.log('\n❌ İşletme bulunamadı:', bizErr?.message);
    rl.close();
    return;
  }

  console.log(`✅ İşletme bulundu: ${business.name}`);

  const token = crypto.randomBytes(32).toString('hex');
  const { data: agent, error: agentErr } = await supabase
    .from('printer_agents')
    .insert({
      business_id: businessId,
      name: agentName,
      token,
      version: '2.0.0',
      last_seen_at: new Date().toISOString(),
    })
    .select('id').single();

  if (agentErr) {
    console.log('\n❌ Agent kaydı oluşturulamadı:', agentErr.message);
    rl.close();
    return;
  }

  console.log(`✅ Agent kaydı: ${agent.id.slice(0, 8)}...`);

  const envContent = `SUPABASE_URL=${supabaseUrl}
SUPABASE_SERVICE_KEY=${supabaseKey}
BUSINESS_ID=${businessId}
AGENT_ID=${agent.id}
AGENT_NAME=${agentName}
PANEL_URL=${panelUrl}
`;

  fs.writeFileSync(envPath, envContent, 'utf8');

  console.log('\n╔════════════════════════════════════════╗');
  console.log('║   ✅ KURULUM TAMAM                     ║');
  console.log('╚════════════════════════════════════════╝');
  console.log('\nBaşlatmak için: baslat.bat (çift tıkla)\n');

  rl.close();
}

main().catch((err) => { console.error('❌', err.message); rl.close(); process.exit(1); });
