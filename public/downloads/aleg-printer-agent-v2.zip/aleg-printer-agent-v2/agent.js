/**
 * ALEG PRINTER AGENT v2.0
 *
 * v1'den farkları:
 * - System tray icon (sağ alt köşe)
 * - Dashboard (localhost HTTP, tarayıcıda açılır)
 * - Çift instance koruma (lock file)
 * - Pause/Resume desteği
 * - Detaylı durum izleme
 */

require('dotenv').config();
const { createClient } = require('@supabase/supabase-js');
const net = require('net');
const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');
const {
  buildKitchenTicket,
  buildCashierReceipt,
  buildTestReceipt,
} = require('./escpos');
const { acquireLock } = require('./lock');
const { TrayController } = require('./tray');
const { DashboardServer, DASHBOARD_URL } = require('./dashboard-server');

// ============================================================
// CONFIG
// ============================================================

const SUPABASE_URL = process.env.SUPABASE_URL;
const SUPABASE_SERVICE_KEY = process.env.SUPABASE_SERVICE_KEY;
const BUSINESS_ID = process.env.BUSINESS_ID;
const AGENT_ID = process.env.AGENT_ID;
const AGENT_NAME = process.env.AGENT_NAME || 'Kafe PC';

if (!SUPABASE_URL || !SUPABASE_SERVICE_KEY || !BUSINESS_ID || !AGENT_ID) {
  console.error('⛔ EKSİK KONFIGÜRASYON');
  console.error('');
  console.error('.env dosyasında şunlar gerekli:');
  console.error('  SUPABASE_URL=https://xxx.supabase.co');
  console.error('  SUPABASE_SERVICE_KEY=...');
  console.error('  BUSINESS_ID=...');
  console.error('  AGENT_ID=...');
  console.error('  AGENT_NAME="Kasa Bilgisayarı"');
  console.error('');
  console.error('İlk kurulum için: npm run setup');
  process.exit(1);
}

const VERSION = '2.0.0';

// ============================================================
// LOCK
// ============================================================

const lockResult = acquireLock();
if (!lockResult.acquired) {
  console.error('');
  console.error('⛔ ALEG AGENT ZATEN ÇALIŞIYOR');
  console.error('');
  console.error(`Çalışan PID: ${lockResult.runningPid}`);
  console.error('Sistem tray\'inde (sağ alt köşe) Aleg ikonunu kontrol edin.');
  console.error('Yeni instance açmak için önce mevcut olanı kapatın.');
  console.error('');
  process.exit(1);
}

// ============================================================
// SUPABASE
// ============================================================

const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_KEY, {
  auth: { persistSession: false },
});

// ============================================================
// LOG
// ============================================================

const LOG_FILE = path.join(__dirname, 'agent.log');

function ts() {
  const d = new Date();
  return `[${d.toLocaleString('tr-TR')}]`;
}
function writeLog(line) {
  try {
    fs.appendFileSync(LOG_FILE, line + '\n', 'utf8');
  } catch {}
}
function log(msg) {
  const line = `${ts()} ${msg}`;
  console.log(line);
  writeLog(line);
}
function logError(msg, err) {
  const line = `${ts()} ❌ ${msg}${err ? ' :: ' + (err.message || err) : ''}`;
  console.error(line);
  writeLog(line);
}
function logSuccess(msg) {
  const line = `${ts()} ✅ ${msg}`;
  console.log(line);
  writeLog(line);
}

// ============================================================
// STATE
// ============================================================

const state = {
  paused: false,
  channel: null,
  heartbeatInterval: null,
};

// ============================================================
// TRAY + DASHBOARD
// ============================================================

const dashboard = new DashboardServer();
const tray = new TrayController({
  agentName: AGENT_NAME,
  dashboardUrl: DASHBOARD_URL,
});

dashboard.updateState({
  agentName: AGENT_NAME,
  version: VERSION,
  status: 'connecting',
  startedAt: new Date().toISOString(),
});

// Tray events
tray.on('open-dashboard', () => {
  log('🌐 Dashboard açılıyor');
  tray.openUrl(DASHBOARD_URL);
});

tray.on('toggle-pause', () => {
  state.paused = !state.paused;
  log(state.paused ? '⏸ Duraklatıldı' : '▶ Devam ediyor');
  tray.setPaused(state.paused);
  dashboard.updateState({ paused: state.paused });
});

tray.on('open-log', () => {
  if (!fs.existsSync(LOG_FILE)) {
    fs.writeFileSync(LOG_FILE, '', 'utf8');
  }
  tray.openPath(LOG_FILE);
});

tray.on('restart', () => {
  log('🔄 Yeniden başlatma talep edildi');
  // baslat.bat döngüsü process.exit(0) sonra tekrar başlatır
  // Eğer doğrudan node ile başlatıldıysa kendi kendine spawn etsin:
  setTimeout(() => {
    try {
      spawn(process.execPath, [path.join(__dirname, 'agent.js')], {
        detached: true, stdio: 'ignore',
      }).unref();
    } catch {}
    process.exit(0);
  }, 250);
});

tray.on('about', () => {
  tray.openUrl(DASHBOARD_URL);
});

tray.on('quit', () => {
  log('🚪 Çıkış talep edildi');
  shutdown();
});

// Dashboard events (web → agent)
dashboard.on('toggle-pause', () => {
  state.paused = !state.paused;
  log(state.paused ? '⏸ Duraklatıldı (dashboard)' : '▶ Devam ediyor (dashboard)');
  tray.setPaused(state.paused);
  dashboard.updateState({ paused: state.paused });
});

dashboard.on('restart', () => {
  log('🔄 Dashboard\'dan yeniden başlatma');
  setTimeout(() => {
    try {
      spawn(process.execPath, [path.join(__dirname, 'agent.js')], {
        detached: true, stdio: 'ignore',
      }).unref();
    } catch {}
    process.exit(0);
  }, 250);
});

dashboard.on('quit', () => {
  log('🚪 Dashboard\'dan çıkış');
  shutdown();
});

// ============================================================
// TCP YAZDIRMA
// ============================================================

function sendToNetworkPrinter(ipAddress, port, data) {
  return new Promise((resolve) => {
    const client = new net.Socket();
    let settled = false;

    const timeout = setTimeout(() => {
      if (settled) return;
      settled = true;
      client.destroy();
      resolve({ success: false, error: `Zaman aşımı (${ipAddress}:${port} yanıt vermedi)` });
    }, 10000);

    client.on('error', (err) => {
      if (settled) return;
      settled = true;
      clearTimeout(timeout);
      resolve({ success: false, error: err.message });
    });

    client.on('close', () => {
      if (settled) return;
      settled = true;
      clearTimeout(timeout);
      resolve({ success: true });
    });

    client.connect(port, ipAddress, () => {
      client.write(data, (err) => {
        if (err) {
          if (settled) return;
          settled = true;
          clearTimeout(timeout);
          client.destroy();
          resolve({ success: false, error: err.message });
          return;
        }
        setTimeout(() => client.end(), 500);
      });
    });
  });
}

// ============================================================
// JOB İŞLEME
// ============================================================

async function processJob(jobId) {
  if (state.paused) {
    log(`⏸ Atlandı (duraklatıldı): ${jobId.slice(0, 8)}…`);
    return;
  }

  log(`📄 Yeni iş: ${jobId.slice(0, 8)}…`);

  // 1. Job + printer
  const { data: job, error: jobErr } = await supabase
    .from('print_jobs')
    .select('*, printer:printer_id(*)')
    .eq('id', jobId)
    .maybeSingle();

  if (jobErr || !job) {
    logError(`Job bulunamadı: ${jobId}`, jobErr);
    return;
  }

  if (job.status !== 'pending') {
    log(`↪ Atlandı (durum: ${job.status})`);
    return;
  }

  const printer = job.printer;
  if (!printer) {
    await markFailed(jobId, 'Yazıcı bulunamadı');
    return;
  }

  if (printer.connection_type !== 'network') {
    log(`↪ Atlandı (${printer.connection_type} - tarayıcı işleyecek)`);
    return;
  }

  if (!printer.ip_address) {
    await markFailed(jobId, 'IP adresi yok');
    return;
  }

  // 2. Atomic claim
  const { error: claimErr, data: claimedRow } = await supabase
    .from('print_jobs')
    .update({ status: 'printing', agent_id: AGENT_ID })
    .eq('id', jobId)
    .eq('status', 'pending')
    .select('id')
    .maybeSingle();

  if (claimErr) {
    logError('Claim başarısız', claimErr);
    return;
  }
  if (!claimedRow) {
    log(`↪ Başkası aldı: ${jobId.slice(0, 8)}…`);
    return;
  }

  // 3. İşletme + sipariş verisi
  const { data: business } = await supabase
    .from('businesses')
    .select('name, tagline_tr, tagline_en, phone, address, logo_url, receipt_settings')
    .eq('id', BUSINESS_ID)
    .maybeSingle();

  if (!business) {
    await markFailed(jobId, 'İşletme bulunamadı');
    return;
  }

  if (!dashboard.state.businessName) {
    dashboard.updateState({ businessName: business.name });
  }

  const settings = business.receipt_settings || {};

  const baseOpts = {
    paperWidth: printer.paper_width || 48,
    businessName: business.name,
    businessTagline: business.tagline_tr || business.tagline_en || undefined,
    businessPhone: business.phone || undefined,
    businessAddress: business.address || undefined,
    customHeader: settings.header_text,
    customFooter: settings.footer_text,
    showLogo: settings.show_logo,
    logoUrl: business.logo_url,
    showTagline: settings.show_tagline,
    showPhone: settings.show_phone,
    showAddress: settings.show_address,
    kitchenBigFont: settings.kitchen_big_font,
    kitchenShowPrices: settings.kitchen_show_prices,
    kitchenShowNoteHighlight: settings.kitchen_show_note_highlight,
    reviewQrEnabled: settings.review_qr_enabled,
    reviewQrText: settings.review_qr_text,
  };

  let bytes;
  let stationName = null;
  let jobLabel = 'Fiş';
  if (job.job_type === 'kitchen' || job.job_type === 'reprint_kitchen') jobLabel = 'Mutfak fişi';
  else if (job.job_type === 'cashier' || job.job_type === 'reprint_cashier') jobLabel = 'Hesap fişi';
  else if (job.job_type === 'test') jobLabel = 'Test';

  // Preview test
  const isPreviewTest =
    !job.order_id &&
    (job.job_type === 'cashier' || job.job_type === 'kitchen') &&
    job.triggered_by === 'manual';

  try {
    if (job.job_type === 'test') {
      bytes = buildTestReceipt(printer.paper_width || 48);
    } else if (isPreviewTest || job.order_id) {
      let orderRow, itemRows;

      if (isPreviewTest) {
        log('  🎬 Önizleme testi');
        orderRow = {
          id: 'preview-test-' + Date.now().toString(36),
          created_at: new Date().toISOString(),
          order_type: 'dine_in',
          table: { name: '4' },
          customer_name: 'Ahmet Yılmaz',
          customer_phone: null,
          note: null,
          subtotal: 130.0,
          total: 130.0,
        };
        itemRows = [
          {
            id: 'mock-item-1', product_id: null, product_name: 'Latte',
            quantity: 2, unit_price: 50.0, note: null,
            station_id: job.station_id || null,
            options: [{ preset_name: 'Süt', value_name: 'Yulaf', price_delta: 5 }],
          },
          {
            id: 'mock-item-2', product_id: null, product_name: 'Kurabiye',
            quantity: 1, unit_price: 25.0, note: 'Fazla kavrulmasın',
            station_id: job.station_id || null, options: [],
          },
        ];

        if (job.station_id) {
          const { data: st } = await supabase
            .from('stations').select('name').eq('id', job.station_id).maybeSingle();
          stationName = st?.name;
        }
      } else {
        const { data: orderData, error: orderErr } = await supabase
          .from('orders')
          .select('*, table:table_id(name)')
          .eq('id', job.order_id)
          .maybeSingle();

        if (orderErr || !orderData) {
          await markFailed(jobId, orderErr ? `Sipariş sorgulanamadı: ${orderErr.message}` : 'Sipariş bulunamadı');
          return;
        }
        orderRow = orderData;

        const { data: items } = await supabase
          .from('order_items').select('*').eq('order_id', job.order_id);
        itemRows = items;

        if (job.station_id) {
          const { data: st } = await supabase
            .from('stations').select('name').eq('id', job.station_id).maybeSingle();
          stationName = st?.name;
        }
      }

      let items = itemRows || [];
      const missingStationIds = items.filter((it) => !it.station_id && it.product_id);
      if (missingStationIds.length > 0) {
        const productIds = [...new Set(missingStationIds.map((it) => it.product_id))];
        const { data: products } = await supabase
          .from('products').select('id, station_id').in('id', productIds);
        const stationMap = new Map();
        (products || []).forEach((p) => { if (p.station_id) stationMap.set(p.id, p.station_id); });
        items = items.map((it) => ({
          ...it,
          station_id: it.station_id || stationMap.get(it.product_id) || null,
        }));
      }

      if ((job.job_type === 'kitchen' || job.job_type === 'reprint_kitchen') && job.station_id) {
        items = items.filter((it) => it.station_id === job.station_id);
      }

      const itemsForPrint = items.map((it) => {
        const rawOpts = Array.isArray(it.options) ? it.options : [];
        return {
          product_name: it.product_name,
          quantity: it.quantity,
          unit_price: it.unit_price,
          note: it.note || null,
          options: rawOpts.map((o) => ({
            preset_name: o.preset_name || '',
            value_name: o.value_name || '',
            price_delta: o.price_delta || 0,
          })),
        };
      });

      const orderData = {
        order_no: orderRow.id.slice(0, 8).toUpperCase(),
        created_at: orderRow.created_at,
        order_type: orderRow.order_type,
        table_label: orderRow.table?.name || null,
        customer_name: orderRow.customer_name,
        customer_phone: orderRow.customer_phone,
        note: orderRow.note,
        subtotal: orderRow.subtotal,
        total: orderRow.total,
        items: itemsForPrint,
      };

      if (baseOpts.reviewQrEnabled && (job.job_type === 'cashier' || job.job_type === 'reprint_cashier')) {
        const panelUrl = process.env.PANEL_URL || 'https://alegstudio.com';
        baseOpts.reviewQrUrl = isPreviewTest
          ? `${panelUrl}/deg/demo`
          : `${panelUrl}/deg/${orderRow.id}`;
      }

      if (job.job_type === 'kitchen' || job.job_type === 'reprint_kitchen') {
        bytes = buildKitchenTicket(orderData, baseOpts, stationName);
      } else {
        const cashierBytes = buildCashierReceipt(orderData, baseOpts);
        const isCashier = job.job_type === 'cashier' || job.job_type === 'reprint_cashier';
        if (isCashier && baseOpts.showLogo !== false && baseOpts.logoUrl) {
          try {
            const { buildLogoBytes } = require('./logo-raster');
            const maxWidth = (printer.paper_width || 48) === 48 ? 200 : 160;
            const logoBytes = await buildLogoBytes(baseOpts.logoUrl, maxWidth);
            bytes = logoBytes ? Buffer.concat([logoBytes, cashierBytes]) : cashierBytes;
          } catch {
            bytes = cashierBytes;
          }
        } else {
          bytes = cashierBytes;
        }
      }
    } else {
      await markFailed(jobId, 'Geçersiz job tipi');
      return;
    }
  } catch (err) {
    logError('Fiş üretme hatası', err);
    await markFailed(jobId, 'Fiş üretilemedi: ' + err.message);
    return;
  }

  // 4. Yazıcıya gönder
  const copies = Math.max(1, Math.min(printer.copies || 1, 5));
  let result = { success: true };

  log(`🖨 Basılıyor → ${printer.name} (${printer.ip_address}:${printer.port}) x${copies}`);

  for (let i = 0; i < copies; i++) {
    result = await sendToNetworkPrinter(printer.ip_address, printer.port || 9100, bytes);
    if (!result.success) break;
    if (i < copies - 1) await new Promise((r) => setTimeout(r, 500));
  }

  if (result.success) {
    await supabase
      .from('print_jobs')
      .update({ status: 'success', completed_at: new Date().toISOString() })
      .eq('id', jobId);

    await supabase
      .from('printer_agents')
      .update({
        last_job_at: new Date().toISOString(),
        jobs_processed: (job.jobs_processed || 0) + 1,
      })
      .eq('id', AGENT_ID);

    logSuccess(`Basıldı → ${printer.name}`);

    dashboard.addJob({
      id: jobId,
      type: job.job_type,
      label: jobLabel,
      printer: printer.name,
      station: stationName,
      success: true,
    });
    tray.setJobsToday(dashboard.state.jobsToday);
  } else {
    await markFailed(jobId, result.error);
    logError(`Basma başarısız: ${result.error}`);

    dashboard.addJob({
      id: jobId,
      type: job.job_type,
      label: jobLabel,
      printer: printer.name,
      station: stationName,
      success: false,
      error: result.error,
    });
  }
}

async function markFailed(jobId, errorMsg) {
  await supabase
    .from('print_jobs')
    .update({
      status: 'failed',
      error_message: errorMsg,
      completed_at: new Date().toISOString(),
    })
    .eq('id', jobId);
}

// ============================================================
// HEARTBEAT
// ============================================================

async function heartbeat() {
  try {
    await supabase
      .from('printer_agents')
      .update({
        last_seen_at: new Date().toISOString(),
        version: VERSION,
      })
      .eq('id', AGENT_ID);
  } catch (err) {
    logError('Heartbeat hatası', err);
  }
}

// ============================================================
// PENDING JOB TARAMA
// ============================================================

async function scanPendingJobs() {
  log('🔍 Bekleyen işler taranıyor…');
  const { data: jobs, error } = await supabase
    .from('print_jobs')
    .select('id, printer:printer_id(connection_type)')
    .eq('status', 'pending')
    .order('created_at', { ascending: true })
    .limit(20);

  if (error) {
    logError('Tarama hatası', error);
    return;
  }

  const networkJobs = (jobs || []).filter((j) => j.printer?.connection_type === 'network');
  if (networkJobs.length === 0) {
    log('  Bekleyen network işi yok');
    return;
  }

  log(`  ${networkJobs.length} iş bulundu, işleniyor…`);
  for (const job of networkJobs) {
    await processJob(job.id);
  }
}

// ============================================================
// SHUTDOWN
// ============================================================

let shuttingDown = false;
async function shutdown() {
  if (shuttingDown) return;
  shuttingDown = true;
  log('👋 Kapatılıyor…');
  try {
    if (state.heartbeatInterval) clearInterval(state.heartbeatInterval);
    if (state.channel) await supabase.removeChannel(state.channel);
    dashboard.stop();
    tray.destroy();
  } catch {}
  process.exit(0);
}

// ============================================================
// MAIN
// ============================================================

async function main() {
  console.log('');
  console.log('╔════════════════════════════════════════╗');
  console.log('║   ALEG PRINTER AGENT v2.0              ║');
  console.log(`║   Agent: ${AGENT_NAME.padEnd(30)}║`);
  console.log('╚════════════════════════════════════════╝');
  console.log('');

  // Tray
  const trayOk = tray.start();
  if (trayOk) {
    log('🟢 Sistem tray icon hazır');
  } else {
    log('⚠ Tray icon başlatılamadı (devam ediliyor)');
  }

  // Dashboard
  const dashUrl = await dashboard.start();
  if (dashUrl) {
    log(`🌐 Dashboard hazır: ${dashUrl}`);
  } else {
    log('⚠ Dashboard başlatılamadı');
  }

  // İlk heartbeat
  await heartbeat();
  logSuccess('Supabase bağlantısı kuruldu');
  tray.setStatus('connected');
  dashboard.updateState({ status: 'connected' });

  // Pending tarama
  await scanPendingJobs();

  // Realtime
  state.channel = supabase
    .channel('print_jobs_agent')
    .on(
      'postgres_changes',
      {
        event: 'INSERT',
        schema: 'public',
        table: 'print_jobs',
        filter: `business_id=eq.${BUSINESS_ID}`,
      },
      async (payload) => {
        if (payload.new.status !== 'pending') return;
        await processJob(payload.new.id);
      }
    )
    .subscribe((status) => {
      if (status === 'SUBSCRIBED') {
        logSuccess('Yeni işler dinleniyor (realtime aktif)');
        log('💡 Sistem tray\'inde Aleg ikonuna tıklayın → Dashboard');
        log('💡 Çıkmak için tray > Çıkış (veya Ctrl+C)');
        tray.setStatus('connected');
        dashboard.updateState({ status: 'connected' });
      } else if (status === 'CHANNEL_ERROR' || status === 'TIMED_OUT' || status === 'CLOSED') {
        tray.setStatus('disconnected', 'Realtime bağlantısı kapandı');
        dashboard.updateState({ status: 'disconnected', errorMsg: 'Realtime bağlantısı kapandı' });
      }
    });

  // Heartbeat
  state.heartbeatInterval = setInterval(heartbeat, 30000);

  // Signals
  process.on('SIGINT', () => shutdown());
  process.on('SIGTERM', () => shutdown());
}

main().catch((err) => {
  logError('Başlatma hatası', err);
  tray.setStatus('error', err.message);
  dashboard.updateState({ status: 'error', errorMsg: err.message });
  setTimeout(() => process.exit(1), 3000);
});
