/**
 * LOGO RASTER - aynısı, dokunmadık
 */
const sharp = require('sharp');
const https = require('https');
const http = require('http');
const GS = 0x1d;

function downloadImage(url) {
  return new Promise((resolve, reject) => {
    const client = url.startsWith('https') ? https : http;
    client.get(url, (res) => {
      if (res.statusCode !== 200) { reject(new Error(`HTTP ${res.statusCode}`)); return; }
      const chunks = [];
      res.on('data', (chunk) => chunks.push(chunk));
      res.on('end', () => resolve(Buffer.concat(chunks)));
      res.on('error', reject);
    }).on('error', reject);
  });
}

async function buildLogoBytes(logoUrl, maxWidth = 200) {
  try {
    let imgBuffer;
    if (logoUrl.startsWith('data:')) {
      const base64 = logoUrl.split(',')[1];
      imgBuffer = Buffer.from(base64, 'base64');
    } else {
      imgBuffer = await downloadImage(logoUrl);
    }

    const targetWidth = Math.floor(maxWidth / 8) * 8;

    const { data: rawData, info } = await sharp(imgBuffer)
      .rotate()
      .resize({ width: targetWidth, fit: 'inside', withoutEnlargement: true })
      .flatten({ background: '#ffffff' })
      .grayscale()
      .threshold(140)
      .raw()
      .toBuffer({ resolveWithObject: true });

    const width = info.width;
    const height = info.height;
    const paddedWidth = Math.ceil(width / 8) * 8;
    const widthBytes = paddedWidth / 8;
    const bitmap = Buffer.alloc(widthBytes * height);

    for (let y = 0; y < height; y++) {
      for (let x = 0; x < paddedWidth; x++) {
        if (x < width) {
          const pixel = rawData[y * width + x];
          if (pixel === 0) {
            const byteIdx = y * widthBytes + Math.floor(x / 8);
            const bitIdx = 7 - (x % 8);
            bitmap[byteIdx] |= (1 << bitIdx);
          }
        }
      }
    }

    const xL = widthBytes & 0xff;
    const xH = (widthBytes >> 8) & 0xff;
    const yL = height & 0xff;
    const yH = (height >> 8) & 0xff;

    const bytes = Buffer.concat([
      Buffer.from([0x1b, 0x61, 0x01]),
      Buffer.from([GS, 0x76, 0x30, 0x00, xL, xH, yL, yH]),
      bitmap,
      Buffer.from([0x1b, 0x61, 0x00]),
      Buffer.from([0x0a]),
    ]);

    return bytes;
  } catch (err) {
    console.error('[logo-raster] Hata:', err.message);
    return null;
  }
}

module.exports = { buildLogoBytes };
