@echo off
chcp 65001 >nul
title Aleg Agent v2 - Otomatik Baslatma

echo.
echo ====================================
echo  ALEG AGENT v2 - OTOMATIK BASLATMA
echo ====================================
echo.
echo Bu script Windows her acildiginda agent'i
echo GIZLI olarak baslatir. Tray icon (sag alt) gorunur.
echo.
pause

set "STARTUP=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup"
set "SCRIPT=%~dp0baslat-gizli.vbs"
set "SHORTCUT=%STARTUP%\AlegPrinterAgent.lnk"

if exist "%SHORTCUT%" del "%SHORTCUT%"

echo.
echo Gizli baslatma kisayoli olusturuluyor:
echo   Konum: %STARTUP%
echo.

powershell -Command "$ws=New-Object -ComObject WScript.Shell; $s=$ws.CreateShortcut('%SHORTCUT%'); $s.TargetPath='wscript.exe'; $s.Arguments='\"%SCRIPT%\"'; $s.WorkingDirectory='%~dp0'; $s.IconLocation='%~dp0icon.ico'; $s.Save()"

if %errorlevel% equ 0 (
    echo.
    echo ====================================
    echo  KURULUM TAMAM
    echo ====================================
    echo.
    echo Test: Windows'u yeniden baslat.
    echo Sag alt kosede Aleg ikonu gorunecek.
    echo.
    echo Kaldirmak icin:
    echo   %STARTUP%
    echo   AlegPrinterAgent.lnk dosyasini silin.
) else (
    echo HATA: Kisayol olusturulamadi.
)

echo.
pause
