@echo off
chcp 65001 >nul
title Aleg Agent - Kapat

echo.
echo  Aleg Printer Agent kapatiliyor...
echo.

REM .agent.lock dosyasindan PID'i al
if not exist .agent.lock (
    echo  Agent calismiyor (lock dosyasi yok).
    echo.
    pause
    exit /b 0
)

set /p PID=<.agent.lock

echo  PID: %PID%
echo  Process sonlandiriliyor...

taskkill /PID %PID% /F >nul 2>&1

if exist .agent.lock del .agent.lock

echo.
echo  Agent kapatildi.
echo.
timeout /t 2 /nobreak >nul
