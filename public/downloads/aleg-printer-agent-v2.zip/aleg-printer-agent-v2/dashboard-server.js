/**
 * DASHBOARD SERVER
 *
 * 127.0.0.1:38274 üzerinde küçük bir HTTP server.
 * Tray icon'una sol tıklayınca tarayıcıda açılır.
 *
 * Routes:
 *   GET /              → dashboard.html (UI)
 *   GET /api/state     → JSON: durum + son işler
 *   GET /api/events    → SSE stream (canlı güncelleme)
 *   POST /api/pause    → duraklat / devam et
 *   POST /api/restart  → yeniden başlat (process.exit + bat döngü)
 *
 * Sadece 127.0.0.1'den erişilebilir (güvenlik).
 */

const http = require('http');
const fs = require('fs');
const path = require('path');
const { EventEmitter } = require('events');

const PORT = 38274; // Aleg = AL.. → 38274 (rastgele ama sabit)
const HOST = '127.0.0.1';

class DashboardServer extends EventEmitter {
  constructor() {
    super();
    this.state = {
      agentName: '',
      version: '',
      status: 'connecting', // connecting / connected / disconnected / error / paused
      paused: false,
      startedAt: new Date().toISOString(),
      jobsToday: 0,
      lastJobAt: null,
      errorMsg: null,
      recentJobs: [], // {id, type, printer, station, success, error, at}
      printers: [],
      businessName: '',
    };
    this.sseClients = new Set();
    this.server = null;
    this.staticHtml = '';
  }

  loadHtml() {
    try {
      this.staticHtml = fs.readFileSync(path.join(__dirname, 'dashboard.html'), 'utf8');
    } catch (err) {
      this.staticHtml = '<h1>dashboard.html bulunamadı</h1>';
    }
  }

  start() {
    this.loadHtml();
    this.server = http.createServer((req, res) => this._handle(req, res));

    return new Promise((resolve) => {
      this.server.listen(PORT, HOST, () => {
        resolve(`http://${HOST}:${PORT}`);
      });
      this.server.on('error', (err) => {
        if (err.code === 'EADDRINUSE') {
          console.error(`[dashboard] Port ${PORT} kullanımda - başka bir instance mı çalışıyor?`);
        } else {
          console.error('[dashboard] hata:', err.message);
        }
        resolve(null);
      });
    });
  }

  stop() {
    if (this.server) {
      this.server.close();
      this.server = null;
    }
    for (const c of this.sseClients) {
      try { c.end(); } catch {}
    }
    this.sseClients.clear();
  }

  // --- State setters ---

  updateState(partial) {
    Object.assign(this.state, partial);
    this._broadcast({ type: 'state', state: this.state });
  }

  addJob(job) {
    this.state.recentJobs.unshift({
      ...job,
      at: job.at || new Date().toISOString(),
    });
    if (this.state.recentJobs.length > 50) {
      this.state.recentJobs.length = 50;
    }
    this.state.jobsToday = this.state.recentJobs.filter((j) => {
      const d = new Date(j.at);
      const now = new Date();
      return d.getDate() === now.getDate() &&
             d.getMonth() === now.getMonth() &&
             d.getFullYear() === now.getFullYear();
    }).length;
    this.state.lastJobAt = this.state.recentJobs[0]?.at || null;
    this._broadcast({ type: 'state', state: this.state });
  }

  // --- Internal ---

  _broadcast(payload) {
    const data = `data: ${JSON.stringify(payload)}\n\n`;
    for (const client of this.sseClients) {
      try { client.write(data); } catch {}
    }
  }

  _handle(req, res) {
    // Sadece 127.0.0.1
    const remote = req.socket.remoteAddress;
    if (remote !== '127.0.0.1' && remote !== '::ffff:127.0.0.1' && remote !== '::1') {
      res.writeHead(403);
      res.end('Forbidden');
      return;
    }

    const url = req.url.split('?')[0];

    if (url === '/' || url === '/index.html') {
      res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
      res.end(this.staticHtml);
      return;
    }

    if (url === '/api/state' && req.method === 'GET') {
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify(this.state));
      return;
    }

    if (url === '/api/events' && req.method === 'GET') {
      res.writeHead(200, {
        'Content-Type': 'text/event-stream',
        'Cache-Control': 'no-cache',
        'Connection': 'keep-alive',
      });
      res.write(`data: ${JSON.stringify({ type: 'state', state: this.state })}\n\n`);
      this.sseClients.add(res);
      req.on('close', () => this.sseClients.delete(res));
      return;
    }

    if (url === '/api/pause' && req.method === 'POST') {
      this.emit('toggle-pause');
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ ok: true }));
      return;
    }

    if (url === '/api/restart' && req.method === 'POST') {
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ ok: true }));
      this.emit('restart');
      return;
    }

    if (url === '/api/quit' && req.method === 'POST') {
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ ok: true }));
      this.emit('quit');
      return;
    }

    res.writeHead(404);
    res.end('Not found');
  }
}

module.exports = { DashboardServer, DASHBOARD_PORT: PORT, DASHBOARD_URL: `http://${HOST}:${PORT}` };
