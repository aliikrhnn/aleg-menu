═══════════════════════════════════════════════════════════
   ALEG PRINTER AGENT v2.0
═══════════════════════════════════════════════════════════

YENİLİKLER (v1'den):
- 🎯 Sistem tray icon (sağ alt köşede Aleg ikonu)
- 🌐 Dashboard penceresi (tarayıcıda açılır, son işler/durum)
- 🔒 Çift instance koruma (yanlışlıkla 2 kez açılamaz)
- ⏸ Pause/Resume desteği
- 🟢 Online/offline/error renk kodlu icon

═══════════════════════════════════════════════════════════
İLK KURULUM
═══════════════════════════════════════════════════════════

1. Node.js yüklü mü? (https://nodejs.org)
   - Komut isteminde "node --version" yazın
   - Yoksa kurun (LTS version)

2. Bu klasördeki kur.bat'a ÇİFT TIKLAYIN
   - npm install çalışır (1-2 dakika)
   - Wizard sorularını cevaplayın:
     * Supabase URL: panelinizden
     * Service Role Key: Supabase Dashboard > Settings > API
     * İşletme ID: panel > Yazıcılar > Agent kurulum
     * Bilgisayar adı: "Kasa PC" gibi

3. baslat.bat'a çift tıklayın
   - Konsol açılır (test için iyi)
   - Sağ alt kösede Aleg ikonu gözükür ✓

═══════════════════════════════════════════════════════════
GÜNLÜK KULLANIM
═══════════════════════════════════════════════════════════

📌 BAŞLATMA SEÇENEKLERİ

  baslat.bat
    → Konsol görünür, debug için iyi
    → Sistem tray'de de ikon gözükür

  baslat-gizli.vbs
    → Hiç pencere açmaz, sadece tray icon
    → Günlük kullanım için ideal

  otomatik-baslat-ekle.bat
    → Windows açılışında otomatik çalışır
    → Çalışmasını garanti eder

📌 TRAY ICON (Sağ Alt Köşe)

  🟢 Yeşil işaretli  → Bağlı, hazır, fiş bekliyor
  🔴 Kırmızı işaretli → Bağlantı sorunu, log'a bakın
  ⚫ Sade            → Bağlanıyor

📌 SAĞ TIK MENÜ

  📊 Dashboard'ı Aç    → Tarayıcıda dashboard açılır
  ⏸  Duraklat / Devam  → Yazdırmayı geçici durdur
  📁 Log Dosyasını Aç  → agent.log not defteri ile
  🔄 Yeniden Başlat    → Bağlantı sorunu varsa
  🚪 Çıkış             → Tamamen kapat

═══════════════════════════════════════════════════════════
DASHBOARD (Tarayıcıda)
═══════════════════════════════════════════════════════════

Tray icon > "Dashboard'ı Aç" tıklayın veya:
http://127.0.0.1:38274 (sadece bu bilgisayardan erişilir)

GÖSTERİR:
  ✓ Bağlantı durumu (canlı)
  ✓ Bugünkü fiş sayısı
  ✓ Son işin saati
  ✓ Çalışma süresi
  ✓ Son 50 fiş listesi (başarılı/başarısız)

YAPABİLİR:
  ⏸ Duraklat / Devam
  🔄 Yeniden başlat

═══════════════════════════════════════════════════════════
ÇİFT FİŞ SORUNUNU NASIL ÇÖZER?
═══════════════════════════════════════════════════════════

ESKİ SORUN: Agent arka planda çalışırken paneli açtınız,
panel sekmesi de aynı işi yazdırdı → 2 fiş çıktı.

YENİ ÇÖZÜM:
  1. Tray icon görünür → "Hâlâ çalıştığını" unutmazsınız
  2. Panel'deki "AGENT AKTİF" badge → sekme yazdırmayı
     atlatır, agent zaten yapıyor
  3. DB-seviyesinde claim → aynı job 2 kez işlenmez

═══════════════════════════════════════════════════════════
SORUN GİDERME
═══════════════════════════════════════════════════════════

❓ "Aleg agent zaten çalışıyor" hatası
  → Görev Yöneticisi > node.exe ara > sonlandır
  → veya kapat.bat çalıştır
  → veya bilgisayarı yeniden başlat

❓ Tray icon görünmüyor
  → Sağ alta tıkla > Bildirim alanı ayarları
  > "Aleg" arasında olabilir, "Açık" yapın
  → veya v1'deki gibi konsoldan kontrol edin

❓ Dashboard açılmıyor
  → http://127.0.0.1:38274 elle yazıp deneyin
  → Firewall engelliyor olabilir (sadece localhost)

❓ Bağlantı hatası
  → İnternet var mı?
  → Supabase'de proje aktif mi?
  → .env dosyasındaki SUPABASE_URL doğru mu?
  → agent.log'a bakın

═══════════════════════════════════════════════════════════
DOSYALAR
═══════════════════════════════════════════════════════════

  agent.js                 Ana script
  tray.js                  Tray icon controller
  dashboard-server.js      HTTP server (localhost)
  dashboard.html           Dashboard UI
  escpos.js                ESC/POS fiş üretici
  logo-raster.js           Logo basma
  lock.js                  Çift instance koruma
  setup.js                 Kurulum wizard

  icon.ico                 Default tray icon
  icon-online.ico          Online (yeşil)
  icon-error.ico           Error (kırmızı)

  baslat.bat               Konsollu başlat
  baslat-gizli.vbs         Gizli başlat (sadece tray)
  kapat.bat                Zorla kapat
  kur.bat                  İlk kurulum
  otomatik-baslat-ekle.bat Windows açılışına ekle

  .env                     Konfigürasyon (gizli!)
  .agent.lock              Lock file (otomatik)
  agent.log                Log dosyası (otomatik)

═══════════════════════════════════════════════════════════
GÜVENLİK
═══════════════════════════════════════════════════════════

⚠ .env dosyasını KİMSEYLE PAYLAŞMAYIN!
  İçinde Supabase Service Role Key var.

⚠ Bu klasörü internet üzerinden başkasıyla paylaşmayın.
  USB ile götürmek tamam.

═══════════════════════════════════════════════════════════
İLETİŞİM
═══════════════════════════════════════════════════════════

Aleg Studio · alegstudio.com
