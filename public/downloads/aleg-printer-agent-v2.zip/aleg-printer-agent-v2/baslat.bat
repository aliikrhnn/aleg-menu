@echo off
chcp 65001 >nul
title Aleg Printer Agent v2

echo.
echo  Aleg Printer Agent v2 baslatiliyor...
echo  Sistem tray'de (sag alt kose) ikon gorunecek.
echo.

:start
call node agent.js

echo.
echo ====================================
echo   Agent durdu - 5 sn sonra tekrar baslayacak
echo   (Durdurmak icin bu pencereyi kapatin)
echo ====================================
echo.
timeout /t 5 /nobreak >nul
goto start
