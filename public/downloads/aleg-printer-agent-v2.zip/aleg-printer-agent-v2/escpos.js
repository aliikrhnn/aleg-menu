/**
 * ESC/POS Builder - Node.js version (for printer agent)
 * Panel'deki lib/printer/escpos.ts'in aynısı
 */

const ESC = 0x1b;
const GS = 0x1d;
const LF = 0x0a;

const CMD = {
  INIT: [ESC, 0x40],
  CUT_PARTIAL: [GS, 0x56, 0x01],
  CP_CP857: [ESC, 0x74, 13],
  ALIGN_LEFT: [ESC, 0x61, 0],
  ALIGN_CENTER: [ESC, 0x61, 1],
  ALIGN_RIGHT: [ESC, 0x61, 2],
  BOLD_ON: [ESC, 0x45, 1],
  BOLD_OFF: [ESC, 0x45, 0],
  SIZE_NORMAL: [GS, 0x21, 0x00],
  SIZE_TALL: [GS, 0x21, 0x01],
  SIZE_WIDE: [GS, 0x21, 0x10],
  SIZE_BIG: [GS, 0x21, 0x11],
};

const TURKISH_MAP = {
  'ç': 0x87, 'Ç': 0x80, 'ğ': 0xa7, 'Ğ': 0xa6,
  'ı': 0x8d, 'İ': 0x98, 'ö': 0x94, 'Ö': 0x99,
  'ş': 0x9f, 'Ş': 0x9e, 'ü': 0x81, 'Ü': 0x9a,
};

const TURKISH_ASCII = {
  'ç': 'c', 'Ç': 'C', 'ğ': 'g', 'Ğ': 'G',
  'ı': 'i', 'İ': 'I', 'ö': 'o', 'Ö': 'O',
  'ş': 's', 'Ş': 'S', 'ü': 'u', 'Ü': 'U',
};

const TURKISH_MODE = process.env.TURKISH_MODE || 'ascii';

function turkishEncode(text) {
  const bytes = [];
  for (const ch of text) {
    if (TURKISH_MODE === 'ascii' && TURKISH_ASCII[ch]) {
      bytes.push(TURKISH_ASCII[ch].charCodeAt(0));
      continue;
    }
    const mapped = TURKISH_MAP[ch];
    if (mapped !== undefined) {
      bytes.push(mapped);
    } else {
      const code = ch.charCodeAt(0);
      bytes.push(code < 128 ? code : 0x3f);
    }
  }
  return bytes;
}

class EscPosBuilder {
  constructor(paperWidth = 48) {
    this.bytes = [];
    this.paperWidth = paperWidth;
    this.bytes.push(...CMD.INIT, ...CMD.CP_CP857);
  }
  raw(b) { this.bytes.push(...b); return this; }
  text(s) { this.bytes.push(...turkishEncode(s)); return this; }
  line(s) { this.text(s); this.bytes.push(LF); return this; }
  newline() { this.bytes.push(LF); return this; }
  left() { this.bytes.push(...CMD.ALIGN_LEFT); return this; }
  center() { this.bytes.push(...CMD.ALIGN_CENTER); return this; }
  right() { this.bytes.push(...CMD.ALIGN_RIGHT); return this; }
  bold(on = true) { this.bytes.push(...(on ? CMD.BOLD_ON : CMD.BOLD_OFF)); return this; }
  normalSize() { this.bytes.push(...CMD.SIZE_NORMAL); return this; }
  tallText() { this.bytes.push(...CMD.SIZE_TALL); return this; }
  wideText() { this.bytes.push(...CMD.SIZE_WIDE); return this; }
  bigText() { this.bytes.push(...CMD.SIZE_BIG); return this; }
  feed(n = 1) { for (let i = 0; i < n; i++) this.bytes.push(LF); return this; }
  cut() { this.bytes.push(...CMD.CUT_PARTIAL); return this; }
  divider() {
    this.bytes.push(LF);
    this.text('-'.repeat(this.paperWidth));
    this.bytes.push(LF);
    return this;
  }
  doubleDivider() {
    this.bytes.push(LF);
    this.text('='.repeat(this.paperWidth));
    this.bytes.push(LF);
    return this;
  }
  twoCol(left, right) {
    const space = this.paperWidth - left.length - right.length;
    if (space <= 0) {
      this.line(left);
      this.right(); this.line(right); this.left();
      return this;
    }
    this.text(left + ' '.repeat(space) + right);
    this.bytes.push(LF);
    return this;
  }
  qrCode(data, size = 6, errorCorrection = 49) {
    const dataBytes = [];
    for (const ch of data) {
      const code = ch.charCodeAt(0);
      dataBytes.push(code < 256 ? code : 0x3f);
    }
    this.bytes.push(GS, 0x28, 0x6b, 0x04, 0x00, 0x31, 0x41, 0x32, 0x00);
    this.bytes.push(GS, 0x28, 0x6b, 0x03, 0x00, 0x31, 0x43, size);
    this.bytes.push(GS, 0x28, 0x6b, 0x03, 0x00, 0x31, 0x45, errorCorrection);
    const dataLen = dataBytes.length + 3;
    const pL = dataLen & 0xff;
    const pH = (dataLen >> 8) & 0xff;
    this.bytes.push(GS, 0x28, 0x6b, pL, pH, 0x31, 0x50, 0x30, ...dataBytes);
    this.bytes.push(GS, 0x28, 0x6b, 0x03, 0x00, 0x31, 0x51, 0x30);
    this.bytes.push(LF);
    return this;
  }
  build() {
    return Buffer.from(this.bytes);
  }
}

function formatMoney(n) { return `${n.toFixed(2)} TL`; }

function formatDateTime(iso) {
  const d = new Date(iso);
  const pad = (n) => n.toString().padStart(2, '0');
  return `${pad(d.getDate())}.${pad(d.getMonth() + 1)}.${d.getFullYear()} ${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

function orderTypeLabel(type) {
  if (type === 'pickup') return 'GEL-AL';
  if (type === 'delivery') return 'PAKET';
  return 'MASA';
}

function buildKitchenTicket(order, opts, stationName) {
  const b = new EscPosBuilder(opts.paperWidth || 48);
  const bigFont = opts.kitchenBigFont !== false;
  const showPrices = opts.kitchenShowPrices === true;
  const noteHighlight = opts.kitchenShowNoteHighlight !== false;

  b.center();
  if (bigFont) b.bigText(); else b.tallText();
  b.bold();
  b.line(stationName ? stationName.toUpperCase() : 'MUTFAK');
  b.bold(false).normalSize();
  b.newline();

  b.center().bigText().bold();
  b.line(`#${order.order_no}`);
  b.bold(false).normalSize();
  b.newline();

  b.center().tallText().bold();
  if (order.order_type === 'dine_in' && order.table_label) {
    b.line(`MASA: ${order.table_label}`);
  } else {
    b.line(orderTypeLabel(order.order_type));
  }
  if (order.customer_name) b.line(order.customer_name.toUpperCase());
  b.bold(false).normalSize();

  b.center();
  b.line(formatDateTime(order.created_at));
  b.divider();

  b.left();
  order.items.forEach((item, i) => {
    if (bigFont) b.tallText();
    b.bold();
    if (showPrices) {
      b.twoCol(`${item.quantity}x ${item.product_name.toUpperCase()}`, formatMoney(item.quantity * item.unit_price));
    } else {
      b.line(`${item.quantity}x ${item.product_name.toUpperCase()}`);
    }
    b.bold(false).normalSize();

    if (item.options && item.options.length > 0) {
      item.options.forEach((opt) => b.text('  * ').line(opt.value_name));
    }
    if (item.note) {
      if (noteHighlight) {
        b.bold().tallText().line(`  >> ${item.note}`).bold(false).normalSize();
      } else {
        b.line(`  Not: ${item.note}`);
      }
    }
    if (i < order.items.length - 1) b.newline();
  });

  if (order.note) {
    b.newline().divider();
    if (noteHighlight) {
      b.bold().tallText().line('MÜŞTERİ NOTU:').normalSize().bold(false);
    } else {
      b.bold().line('MÜŞTERİ NOTU:').bold(false);
    }
    b.line(order.note);
  }

  b.feed(4).cut();
  return b.build();
}

function buildCashierReceipt(order, opts) {
  const b = new EscPosBuilder(opts.paperWidth || 48);
  const showTagline = opts.showTagline !== false;
  const showPhone = opts.showPhone !== false;
  const showAddress = opts.showAddress !== false;

  b.center().bigText().bold();
  b.line(opts.businessName.toUpperCase());
  b.bold(false).normalSize();

  if (showTagline && opts.businessTagline) b.center().line(opts.businessTagline);
  if (showAddress && opts.businessAddress) b.center().line(opts.businessAddress);
  if (showPhone && opts.businessPhone) b.center().line(`Tel: ${opts.businessPhone}`);
  if (opts.customHeader && opts.customHeader.trim()) {
    b.newline().center().line(opts.customHeader);
  }

  b.doubleDivider();

  b.left();
  b.twoCol('Sipariş No:', `#${order.order_no}`);
  b.twoCol('Tarih:', formatDateTime(order.created_at));
  b.twoCol('Tip:', orderTypeLabel(order.order_type));
  if (order.order_type === 'dine_in' && order.table_label) {
    b.twoCol('Masa:', order.table_label);
  }
  if (order.customer_name) b.twoCol('Musteri:', order.customer_name);
  if (order.customer_phone) b.twoCol('Telefon:', order.customer_phone);

  b.divider();

  order.items.forEach((item) => {
    const lineTotal = item.quantity * item.unit_price;
    b.bold();
    b.twoCol(`${item.quantity}x ${item.product_name}`, formatMoney(lineTotal));
    b.bold(false);

    if (item.options && item.options.length > 0) {
      item.options.forEach((opt) => {
        const deltaStr = opt.price_delta !== 0
          ? ` (${opt.price_delta > 0 ? '+' : ''}${opt.price_delta}TL)`
          : '';
        b.line(`  + ${opt.value_name}${deltaStr}`);
      });
    }
    if (item.note) b.line(`  Not: ${item.note}`);
  });

  b.divider();
  b.twoCol('Ara toplam:', formatMoney(order.subtotal));
  b.bold().bigText();
  b.twoCol('TOPLAM:', formatMoney(order.total));
  b.bold(false).normalSize();

  if (opts.customFooter && opts.customFooter.trim()) {
    b.newline().center().line(opts.customFooter);
  }

  if (opts.reviewQrEnabled && opts.reviewQrUrl) {
    b.newline();
    b.divider();
    b.center();
    b.bold().line(opts.reviewQrText || 'Deneyiminizi degerlendirin').bold(false);
    b.newline();
    b.qrCode(opts.reviewQrUrl, 6, 49);
    b.center().line('Karekodu okutun');
  }

  b.newline().center().line('Aleg POS');
  b.feed(4).cut();
  return b.build();
}

function buildTestReceipt(paperWidth = 48) {
  const b = new EscPosBuilder(paperWidth);
  b.center().bigText().bold();
  b.line('ALEG TEST');
  b.bold(false).normalSize();
  b.doubleDivider();
  b.left();
  b.line(`Kağıt: ${paperWidth === 48 ? '80mm' : '58mm'}`);
  b.line(`Zaman: ${formatDateTime(new Date().toISOString())}`);
  b.line('Baglanti: AGENT / NETWORK');
  b.divider();
  b.center();
  b.line('Bu bir test fişidir.');
  b.line('Turkçe karakter: çğıöşüÇĞİÖŞÜ');
  b.feed(4).cut();
  return b.build();
}

module.exports = {
  EscPosBuilder,
  buildKitchenTicket,
  buildCashierReceipt,
  buildTestReceipt,
};
