/**
 * LOCK FILE — Çift instance koruma
 *
 * Agent başlatılınca lock.pid dosyasına PID yazar.
 * 2. kez başlatılırsa eski PID'i kontrol eder:
 *   - Hâlâ çalışıyorsa → uyarı + çık
 *   - Çalışmıyorsa (kalıntı) → lock'u al, devam
 */

const fs = require('fs');
const path = require('path');
const os = require('os');

const LOCK_FILE = path.join(__dirname, '.agent.lock');

function isProcessRunning(pid) {
  try {
    // process.kill(pid, 0) → sinyal göndermez ama process var mı kontrol eder
    process.kill(pid, 0);
    return true;
  } catch (err) {
    // ESRCH = process yok
    return err.code !== 'ESRCH';
  }
}

/**
 * Lock'u almaya çalış. Başarılıysa true, başkası tutmuşsa false.
 */
function acquireLock() {
  if (fs.existsSync(LOCK_FILE)) {
    try {
      const oldPid = parseInt(fs.readFileSync(LOCK_FILE, 'utf8').trim(), 10);
      if (oldPid && oldPid !== process.pid && isProcessRunning(oldPid)) {
        return { acquired: false, runningPid: oldPid };
      }
      // Kalıntı lock — sil
      fs.unlinkSync(LOCK_FILE);
    } catch (err) {
      // Lock dosyası bozuk — sil
      try { fs.unlinkSync(LOCK_FILE); } catch {}
    }
  }

  fs.writeFileSync(LOCK_FILE, String(process.pid), 'utf8');

  // Çıkışta lock'u temizle
  const cleanup = () => {
    try {
      if (fs.existsSync(LOCK_FILE)) {
        const ownPid = parseInt(fs.readFileSync(LOCK_FILE, 'utf8').trim(), 10);
        if (ownPid === process.pid) fs.unlinkSync(LOCK_FILE);
      }
    } catch {}
  };

  process.on('exit', cleanup);
  process.on('SIGINT', () => { cleanup(); process.exit(0); });
  process.on('SIGTERM', () => { cleanup(); process.exit(0); });
  process.on('uncaughtException', (err) => {
    console.error('Uncaught:', err);
    cleanup();
    process.exit(1);
  });

  return { acquired: true };
}

module.exports = { acquireLock, LOCK_FILE };
