@echo off
chcp 65001 >nul
title Aleg Printer Agent v2 - Kurulum

echo.
echo ====================================
echo    ALEG PRINTER AGENT v2 - KURULUM
echo ====================================
echo.

where node >nul 2>&1
if %errorlevel% neq 0 (
    echo HATA: Node.js yuklenmemis!
    echo Lutfen https://nodejs.org adresinden indirin.
    pause
    exit /b 1
)

echo Node.js versiyonu:
node --version
echo.

echo Bagimliliklar yukleniyor (birkac dakika surebilir)...
echo.
call npm install

if %errorlevel% neq 0 (
    echo HATA: npm install basarisiz.
    pause
    exit /b 1
)

echo.
echo ====================================
echo    BAGIMLILIKLAR YUKLENDI
echo ====================================
echo.
echo Simdi konfigurasyon wizardi aciliyor...
echo.
pause

call node setup.js

echo.
pause
